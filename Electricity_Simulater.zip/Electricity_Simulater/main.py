import pygame
import os
import updater as upd
import numpy as np
import config
pygame.init()

screen = pygame.display.set_mode((800, 600))

# grid_size = 5, 5
pixel_scalar = 4
electron_spawn_perc = 0.075

project_path = "/storage/emulated/0/Python Projects/Electricity_Simulater"
with open(f"{project_path}/build.txt") as file:
    data = np.array(file.read().replace("\n", "").split(), dtype=np.uint8)
    grid_size = tuple(data[0: 2])
    material_array = data[2:].reshape(grid_size)

tile_textures = []
for p in sorted(os.listdir(f"{project_path}/assets")):
    img = pygame.image.load(f"{project_path}/assets/{p}")
    img = pygame.transform.scale(img, (16 * pixel_scalar, 16 * pixel_scalar))
    
    tile_textures .append(pygame.surfarray.array3d(img))
tile_textures = np.array(tile_textures)

def texture_grid_to_surface(texture_grid):
    grid_array = np.array(texture_grid)

    combined = grid_array.transpose(1, 3, 0, 2, 4)

    combined = combined.reshape(
        combined.shape[0] * combined.shape[1],
        combined.shape[2] * combined.shape[3],
        3)

    return pygame.surfarray.make_surface(combined.swapaxes(0, 1))

def spawn(x, y):
    config.electron_x = np.append(config.electron_x, x)
    config.electron_y = np.append(config.electron_y, y)
    config.electron_x_vel = np.append(config.electron_x_vel, 0)
    config.electron_y_vel = np.append(config.electron_y_vel, 0)

for y, row in enumerate(material_array):
    for x, material in enumerate(row):
        amount = int(config.conductivity[material] / electron_spawn_perc)

        for i in range(amount):
            spawn(y * 16 * pixel_scalar + 8 * pixel_scalar, x * 16 * pixel_scalar + 8 * pixel_scalar)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((0, 0, 0))
    
    texture_grid = tile_textures[material_array]
    surface = texture_grid_to_surface(texture_grid)
    config.map_surface = surface
    config.map_array = material_array
    screen.blit(surface, (0, 0))
    
    for x, y in zip(config.electron_x, config.electron_y):
        pygame.draw.circle(screen, (50, 50, 255), (x, y), 5)
    
    upd.update() 
    
    pygame.display.flip()        
pygame.quit()