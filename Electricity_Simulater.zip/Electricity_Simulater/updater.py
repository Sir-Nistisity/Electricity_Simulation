import numpy as np
import config as c

def update():
    spawned = len(c.electron_x)
    
    current_tile = c.map_array[c.electron_y][c.electron_x]
    
    c.electron_x += c.electron_x_vel
    c.electron_y += c.electron_y_vel
    
    c.electron_x = c.electron_x % c.map_surface.get_width()
    c.electron_y = c.electron_y % c.map_surface.get_height()